import 'package:flutter/material.dart';
import 'package:pj/OrderHistoryPage.dart';
import '../database/model.dart';
import 'package:pj/pages/product_user.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:pj/main.dart';


class ShoppingCartPage extends StatefulWidget {
  final List<Product> selectedItems;
  final String userEmail;
  final VoidCallback resetCart; // Add a callback for resetting the cart
  

  ShoppingCartPage({
    required this.selectedItems,
    required this.userEmail,
    required this.resetCart,
  });

  @override
  _ShoppingCartPageState createState() => _ShoppingCartPageState();
}

class _ShoppingCartPageState extends State<ShoppingCartPage> {
  double calculateTotal(List<Product> selectedItems) {
    return selectedItems.fold(0, (sum, item) => sum + (item.price * 1));
  }

Future<void> sendToFirestore(String userEmail, List<Product> selectedItems, double total) async {
  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  // Create a new Firestore document for the order
  final CollectionReference orders = firestore.collection('orders');
  final List<Map<String, dynamic>> orderItems = selectedItems.map((item) {
    return {
      'name': item.name,
      'price': item.price,
      'quantity': 1, // Assuming quantity is always 1 for this example
    };
  }).toList();

  final Map<String, dynamic> orderData = {
    'userEmail': userEmail,
    'items': orderItems, // Store the items as an array
    'total': total, // Use the total passed as an argument
    'timestamp': FieldValue.serverTimestamp(), // Optionally, include a timestamp
  };

  await orders.add(orderData);
}

  @override
  Widget build(BuildContext context) {
    double total = calculateTotal(widget.selectedItems);

    return Scaffold(
      appBar: AppBar(
        title: Text('Shopping Cart'),
      ),
      body: ListView.builder(
        itemCount: widget.selectedItems.length,
        itemBuilder: (context, index) {
          final product = widget.selectedItems[index];
          total += (product.price * 1);
          return ListTile(
            title: Text(product.name),
            subtitle: Text('Price: ${product.price.toString()}'),
          );
        },
      ),
      bottomNavigationBar: Container(
        padding: EdgeInsets.all(16),
        color: Colors.blue,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Order Information',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              'User Email: ${widget.userEmail}',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
              ),
            ),
            SizedBox(height: 16),
            Text(
              'List of Items Bought',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            Column(
              children: widget.selectedItems.map((product) {
                final itemName = product.name;
                final itemPrice = product.price;
                final itemQuantity = 1; // Assuming quantity is always 1 for this example
                final itemTotal = itemPrice * itemQuantity;
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Name: $itemName',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                      ),
                    ),
                    Text(
                      'Quantity: $itemQuantity',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                      ),
                    ),
                    Text(
                      'Price per Unit: \$${itemPrice.toStringAsFixed(2)}',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                      ),
                    ),
                    Text(
                      'Total Price: \$${itemTotal.toStringAsFixed(2)}',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                      ),
                    ),
                    SizedBox(height: 16),
                  ],
                );
              }).toList(),
            ),
            Text(
              'Total: \$${total.toStringAsFixed(2)}',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              'Quantity: ${widget.selectedItems.length}',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            ElevatedButton(
                onPressed: () async {
                  final user = FirebaseAuth.instance.currentUser;
                  if (user != null) {
                    final userEmail = user.email ?? '';
                    final total = calculateTotal(widget.selectedItems);

                    // Call the function to send data to Firebase Firestore
                    await sendToFirestore(userEmail, widget.selectedItems, total);

                    // Create order details
                    final List<OrderDetail> details = widget.selectedItems.map((item) {
                      return OrderDetail(
                        orderId: 'order_id', // Replace with your order ID logic
                        productName: item.name,
                        pricePerUnit: item.price,
                        quantity: 1, // Assuming quantity is always 1 for this example
                      );
                    }).toList();

                    // You can also show a confirmation dialog or navigate to a confirmation page.
                    // For now, we'll just print a message.
                    print('Order placed successfully!');
                    // Clear the cart
                    widget.resetCart();

                    // Navigate to OrderHistoryPage and pass user's email and total
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => OrderHistoryPage(
                            selectedItems: widget.selectedItems,
                            userEmail: userEmail,
                            total: total, // Pass the total
                          ),
                        ),
                      );
                  } else {
                    // Handle the case where the user is not authenticated.
                    print('User is not authenticated.');
                  }
                },
                child: Text('Checkout'),
              ),
            ElevatedButton(
              onPressed: () {
                widget.resetCart(); // Call the resetCart function
                Navigator.pop(context);
              },
              child: Text('Reset'),
            ),
          ],
        ),
      ),
    );
  }
}
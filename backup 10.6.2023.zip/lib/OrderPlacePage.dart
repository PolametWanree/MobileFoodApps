// import 'package:flutter/material.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:carousel_slider/carousel_slider.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:pj/database/model.dart';
// import 'package:pj/database/database_helper.dart';
// import 'package:pj/pages/login.dart';
// import 'package:pj/pages/product_user.dart';

// class OrderPlacePage extends StatefulWidget {
//   final List<OrderDetail> selectedItems;

//   OrderPlacePage({
//     required this.selectedItems,
//   });

//   @override
//   _OrderPlacePageState createState() => _OrderPlacePageState();
// }

// class _OrderPlacePageState extends State<OrderPlacePage> {
//   List<Product> selectedProducts = [];

//   @override
//   void initState() {
//     super.initState();
//     // Fetch product details for selected items
//     fetchProductDetailsFromFirestore(widget.selectedItems).then((products) {
//       setState(() {
//         selectedProducts = products;
//       });
//     });
//   }

//   Future<List<Product>> fetchProductDetailsFromFirestore(List<OrderDetail> orderDetails) async {
//     try {
//       final productNames = orderDetails.map((orderDetail) => orderDetail.productName).toList();
//       final productDetails = <Product>[];

//       final snapshot = await FirebaseFirestore.instance
//           .collection('products')
//           .where(FieldPath.documentId, whereIn: productNames)
//           .get();

//       snapshot.docs.forEach((productDocument) {
//         final productData = productDocument.data();
//         final product = Product(
//           name: productDocument.id,
//           description: productData['description'] ?? '',
//           price: (productData['price'] as num).toDouble(),
//           quantity: productData['quantity'] ?? 0,
//           favorite: productData['favorite'] ?? 0,
//         );

//         // Find the corresponding order detail and update it with the orderId and quantity
//         OrderDetail? orderDetailToUpdate;

//         for (final orderDetail in orderDetails) {
//           if (orderDetail.productName == product.name) {
//             orderDetailToUpdate = orderDetail;
//             break;
//           }
//         }

//         if (orderDetailToUpdate != null) {
//           orderDetailToUpdate.orderId = 'your_order_id'; // Replace with your actual orderId logic
//           orderDetailToUpdate.quantity = 1; // Set the quantity to 1 for now, update it with the actual quantity
//         }

//         productDetails.add(product);
//       });

//       return productDetails;
//     } catch (e) {
//       print('Error fetching product details: $e');
//       return [];
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Order Place'),
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text(
//               'Received Order',
//               style: TextStyle(
//                 fontSize: 24,
//                 fontWeight: FontWeight.bold,
//               ),
//             ),
//             SizedBox(height: 16),
//             // Display the received order details with name, quantity, and price
//             Column(
//               children: selectedProducts.map((selectedProduct) {
//                 final orderDetail = widget.selectedItems.firstWhere(
//                   (detail) => detail.productName == selectedProduct.name,
//                   orElse: () => OrderDetail(
//                     orderId: '', // Set orderId to empty for now, you'll need to update this with the actual orderId
//                     productName: selectedProduct.name,
//                     pricePerUnit: selectedProduct.price,
//                     quantity: 0, // Set quantity to 0 for now, you'll need to update this with the actual quantity
//                   ),
//                 );

//                 return ListTile(
//                   title: Text(selectedProduct.name),
//                   subtitle: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Text(
//                         'Quantity: ${orderDetail.quantity}',
//                       ),
//                       Text(
//                         'Price: \$${selectedProduct.price.toStringAsFixed(2)}',
//                       ),
//                     ],
//                   ),
//                 );
//               }).toList(),
//             ),
//             if (selectedProducts.isEmpty)
//               Text('No order details found.'), // Display a message for no orders
//           ],
//         ),
//       ),
//     );
//   }
// }
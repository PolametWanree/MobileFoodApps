import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:pj/OrderHistoryPage.dart';
import 'package:pj/OrderPlacePage.dart'; // Import the OrderPlacePage
import 'package:pj/database/database_helper.dart';
import 'package:pj/database/model.dart';
import 'package:pj/pages/login.dart';
import 'package:pj/pages/product_user.dart';
import 'package:carousel_slider/carousel_slider.dart';

class Student extends StatefulWidget {
  const Student({Key? key}) : super(key: key);

  @override
  State<Student> createState() => _StudentState();
}

class _StudentState extends State<Student> {
  List<Product> selectedItems = [];
  double total = 0.0; // Initialize total

  final List<String> imagePaths = [
    'assets/images/BG1.jpg',
    'assets/images/t1.jpg',
    'assets/images/dog1.jpg',
    'assets/images/dog2.jpg',
    // Add more image paths as needed
  ];

  String? userEmail = FirebaseAuth.instance.currentUser?.email; // Define userEmail here

  void addToSelectedItems(Product item) {
    setState(() {
      selectedItems.add(item);
      total += item.price; // Update total when an item is added
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Student"),
        actions: [
          IconButton(
            onPressed: () {
              logout(context);
            },
            icon: Icon(
              Icons.logout,
            ),
          )
        ],
      ),
      body: SafeArea(
        child: ListView(
          children: [
            Container(
              height: 57.6,
              margin: EdgeInsets.only(top: 28.8, left: 28.8, right: 28.8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  GestureDetector(
                    onTap: () {
                      // Add your action here when the search icon is tapped
                    },
                    child: Container(
                      height: 57.6,
                      width: 57.6,
                      padding: EdgeInsets.all(18),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(9.6),
                        color: Color(0x080a0928),
                      ),
                      child: Icon(Icons.list),
                    ),
                  ),
                  Container(
                    height: 57.6,
                    width: 57.6,
                    padding: EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(9.6),
                      color: Color(0x080a0928),
                    ),
                    child: Icon(Icons.search),
                  )
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: 70, left: 28.8, bottom: 50),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'MY Store',
                    style: TextStyle(
                      fontFamily: 'Kanit',
                      fontSize: 75,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    'ร้านค้าเพื่อการศึกษาอยากหาอะไรก็สะกิดมาไอสัสไม่ต้องถามมาก',
                    style: TextStyle(
                      fontFamily: 'Kanit',
                      fontSize: 18,
                    ),
                  ),
                ],
              ),
            ),
            CarouselSlider(
              options: CarouselOptions(
                aspectRatio: 16 / 9,
                enlargeCenterPage: true,
                autoPlay: true,
              ),
              items: imagePaths.map((imagePath) {
                return Builder(
                  builder: (BuildContext context) {
                    return Container(
                      width: 700,
                      height: 100,
                      margin: EdgeInsets.symmetric(horizontal: 5.0),
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage(imagePath),
                          fit: BoxFit.cover,
                        ),
                      ),
                    );
                  },
                );
              }).toList(),
            ),
            Padding(
              padding: EdgeInsets.only(top: 70, left: 28.8, bottom: 50),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  GestureDetector(
                    onTap: () async {
                      if (userEmail != null) {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ProductUserScreen(
                              dbHelper: DatabaseHelper(),
                              userEmail: userEmail!,
                            ),
                          ),
                        );
                      } else {
                        print('User is not authenticated.');
                      }
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(15.0),
                      child: CircleAvatar(
                        backgroundColor: Colors.black,
                        radius: 30,
                        child: Icon(
                          Icons.shopping_cart,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                  GestureDetector(
                        onTap: () async {
                          if (userEmail != null) {
                            // Navigate to the OrderHistoryPage and pass the selectedItems and total
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => OrderHistoryPage(
                                  selectedItems: selectedItems,
                                  userEmail: userEmail,
                                  total: total,
                                ),
                              ),
                            );
                          } else {
                            print('User is not authenticated.');
                          }
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(15.0),
                          child: CircleAvatar(
                            backgroundColor: Colors.black,
                            radius: 30,
                            child: Icon(
                              Icons.info,
                              color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> logout(BuildContext context) async {
    await FirebaseAuth.instance.signOut();
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => LoginPage(),
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    home: Student(),
  ));
}

import 'package:flutter/material.dart';
import 'package:pj/database/model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class OrderHistoryPage extends StatefulWidget {
  final List<Product> selectedItems;
  final String? userEmail;
  final double total; // Add the total parameter

  OrderHistoryPage({
    required this.selectedItems,
    required this.userEmail,
    required this.total, // Include the total parameter
  });

  @override
  _OrderHistoryPageState createState() => _OrderHistoryPageState();
}

class _OrderHistoryPageState extends State<OrderHistoryPage> {
  get orderDetails => null;

  Future<void> sendToFirestore() async {
    final FirebaseFirestore firestore = FirebaseFirestore.instance;

    // Create a new Firestore document for the order
    final CollectionReference orders = firestore.collection('orders');
    final List<Map<String, dynamic>> orderItems = widget.selectedItems.map((item) {
      return {
        'name': item.name,
        'price': item.price,
        'quantity': 1, // Assuming quantity is always 1 for this example
      };
    }).toList();

    final Map<String, dynamic> orderData = {
      'userEmail': widget.userEmail,
      'items': orderItems, // Store the items as an array
      'total': calculateTotal(widget.selectedItems), // Calculate and include the total price
      'timestamp': FieldValue.serverTimestamp(), // Optionally, include a timestamp
    };

    await orders.add(orderData);
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Order History'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Recent Purchase',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 16),
            FutureBuilder<List<OrderDetail>>(
              future: orderDetails,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return CircularProgressIndicator(); // Display loading indicator
                } else if (snapshot.hasError) {
                  return Text('Error: ${snapshot.error}');
                } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return Text('No order details found.');
                } else {
                  final orderDetails = snapshot.data!;
                  return Column(
                    children: orderDetails.map((orderDetail) {
                      return ListTile(
                        title: Text(orderDetail.productName),
                        subtitle: Text(
                          'Price: \$${orderDetail.pricePerUnit.toStringAsFixed(2)}'),
                      );
                    }).toList(),
                  );
                }
              },
            ),
            Text(
              'Total: \$${widget.total.toStringAsFixed(2)}', // Access the total parameter
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  calculateTotal(List<Product> selectedItems) {}
}
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:pj/database/database_helper.dart';
import 'package:pj/pages/product.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'pages/login.dart';

class Overall extends StatefulWidget {
  const Overall({super.key});

  @override
  State<Overall> createState() => _OverallState();
}

class _OverallState extends State<Overall> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Shopping PG',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSwatch(primarySwatch: Colors.deepPurple),
        fontFamily: 'Kanit',
  

      ),
   
    );
  }
}

class MyHomepage extends StatefulWidget {
  const MyHomepage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<MyHomepage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomepage> {
  final List<String> imagePaths = [
    'assets/images/BG1.jpg',
    'assets/images/t1.jpg',
    'assets/images/dog1.jpg',
    'assets/images/dog2.jpg',
    // Add more image paths as needed
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.primary,
        title: Text(widget.title),
        actions: [
          IconButton(
            icon: Icon(Icons.shopping_cart),
            onPressed: () {
              // Add your icon's action here
             Navigator.of(context).push(
  MaterialPageRoute(
    builder: (context) => ProductScreen(dbHelper: DatabaseHelper()),
  ),
);
            },
          ),
        ],
      ),
      body: SafeArea(
        child: Container(
          child: ListView(
            physics: BouncingScrollPhysics(),
            children: <Widget>[
              Container(
                height: 57.6,
                margin: EdgeInsets.only(top: 28.8, left: 28.8, right: 28.8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                  GestureDetector(
                      onTap: () {
                        // Add your action here when the search icon is tapped
                        // For example, you can open a search screen or perform a search action.
              //         Navigator.push(
              //   context,
              //   MaterialPageRoute(
              //     builder: (context) => const PageAdminScreen(),
              //   ),
              // );
                      },
                      child: Container(
                        height: 57.6,
                        width: 57.6,
                        padding: EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(9.6),
                          color: Color(0x080a0928),
                        ),
                        child: Icon(Icons.list),
                      ),
                    ),

                    Container(
                      height: 57.6,
                      width: 57.6,
                      padding: EdgeInsets.all(18),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(9.6),
                        color: Color(0x080a0928),
                      ),
                      child: Icon(Icons.search),
                    )
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.only(top: 70, left: 28.8,bottom: 50),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'MY Store',
                      style: TextStyle(
                        fontFamily: 'Kanit',
                        fontSize: 75, // Adjust the font size as needed
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      'ร้านค้าเพื่อการศึกษาอยากหาอะไรก็สะกิดมาไอสัสไม่ต้องถามมาก',
                      style: TextStyle(
                        fontFamily: 'Kanit',
                        fontSize: 18, // Adjust the font size as needed
                      ),
                    ),
                  ],
                ),
              ),



           CarouselSlider(
            options: CarouselOptions(
              aspectRatio: 16 / 9, // You can adjust the aspect ratio as needed
              enlargeCenterPage: true,
              autoPlay: true,
            ),
            items: imagePaths.map((imagePath) {
              return Builder(
                builder: (BuildContext context) {
                  return Container(
                    width: 700, // Set the desired width for the image
                    height: 100, // Set the desired height for the image
                    margin: EdgeInsets.symmetric(horizontal: 5.0),
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage(imagePath), // Adjust the image path as needed
                        fit: BoxFit.cover,
                      ),
                    ),
                  );
                },
              );
            }).toList(),
          ),



         Padding(
     padding: EdgeInsets.only(top: 70, left: 28.8,bottom: 50),
           child: Row(
           mainAxisAlignment: MainAxisAlignment.center,
           children: [
             GestureDetector(
               onTap: () {
                 // Add your action here when the first CircleAvatar is pressed
             Navigator.of(context).push(
  MaterialPageRoute(
    builder: (context) => ProductScreen(dbHelper: DatabaseHelper()),
  ),
);
               },
               child: Padding(
                 padding: const EdgeInsets.all(15.0), // Add your desired padding here
                 child: CircleAvatar(
            backgroundColor: Colors.black,
            radius: 30,
            child: Icon(
              Icons.shopping_cart, // Add your desired icon here
              color: Colors.white, // Customize the icon color
            ),
                 ),
               ),
             ),
             GestureDetector(
               onTap: () {
                 // Add your action here when the second CircleAvatar is pressed
              //  Navigator.push(
              //   context,
              //   MaterialPageRoute(
              //     builder: (context) => const Page2Screen(),
              //   ),
              // );
               },
               child: Padding(
                 padding: const EdgeInsets.all(15.0), // Add your desired padding here
                 child: CircleAvatar(
            backgroundColor: Colors.black,
            radius: 30,
            child: Icon(
              Icons.info, // Add your desired icon here
              color: Colors.white, // Customize the icon color
            ),
                 ),
               ),
             ),
             GestureDetector(
               onTap: () {
                 // Add your action here when the third CircleAvatar is pressed
              //     Navigator.push(
              //   context,
              //   MaterialPageRoute(
              //     builder: (context) => const Page3Screen(),
              //   ),
              // );
               },
               child: Padding(
                 padding: const EdgeInsets.all(15.0), // Add your desired padding here
                 child: CircleAvatar(
            backgroundColor: Colors.black,
            radius: 30,
            child: Icon(
              Icons.favorite, // Add your desired icon here
              color: Colors.white, // Customize the icon color
            ),
                 ),
               ),
             ),
             GestureDetector(
               onTap: () {
                 // Add your action here when the fourth CircleAvatar is pressed
              //  Navigator.push(
              //   context,
              //   MaterialPageRoute(
              //     builder: (context) => const Page4Screen(),
              //   ),
              // );
               },
               child: Padding(
                 padding: const EdgeInsets.all(15.0), // Add your desired padding here
                 child: CircleAvatar(
            backgroundColor: Colors.black,
            radius: 30,
            child: Icon(
              Icons.star, // Add your desired icon here
              color: Colors.white, // Customize the icon color
            ),
                 ),
               ),
             ),
           ],
         ),
         )




            ],
          ),
        ),
      ),
    );
  }
}